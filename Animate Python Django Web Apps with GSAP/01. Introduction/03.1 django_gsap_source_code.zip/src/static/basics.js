// const box = document.getElementById('box')

// gsap.from() - from defiend state using gsap to the html/css state

// gsap.from(box, 
//     {
//         opacity:0,
//         delay: 1,
//         duration: 1,
//         scale: 0.2,
//         rotation: 90,
//         backgroundColor: 'blue',
//         skewX:30,
//     }
// )

// gsap.to() - from state defiend in html/css to the one in gsap

// gsap.to(box, 
//     {
//         rotation: 45,
//         delay: 1,
//         backgroundColor: 'yellow',
//         duration: 2,
//         borderRadius: '50%',
//         opacity: 1,
//     }    
// )

// gsap.fromTo() - in gsap we define both states

// gsap.fromTo(box, 
//     {
//         opacity: 0,
//         y: 400,
//     },
//     {
//         y: -100,
//         opacity: 1,
//         delay: 1,
//         duration: 2,
//         ease: 'steps(6)',
//     }
// )

const boxes = document.getElementsByClassName("box")

const myAnimation = gsap.to(boxes, 
    {
        y: -200,
        delay: 1,
        stagger: {
            each: 0.25,
            from: 'end'
        },
        repeat: 3,
        repeatDelay: 1,
        paused: true,
        autoAlpha: 0,
        yoyo: true,
    }    
)

// myAnimation.pause()

document.getElementById('play').addEventListener('click', () => {
    myAnimation.play()
})

document.getElementById('pause').addEventListener('click', () => {
    myAnimation.pause()
})

document.getElementById('reset').addEventListener('click', () => {
    myAnimation.restart()
})

document.getElementById('reverse').addEventListener('click', () => {
    myAnimation.reverse()
})