// HERO
const heroTexts = document.querySelectorAll(".hero-text")

gsap.from(
    heroTexts,
    {
        opacity: 0,
        skewY: 15,
        y: 100,
        stagger: 0.2
    },
)

// ABOUT
const aboutHeader = document.getElementById("about-header")
const aboutDescription = document.getElementById("about-description")

const tlAbout = gsap.timeline()

tlAbout.from(aboutHeader,
    {
        opacity: 0,
        y: 50
    }
)
tlAbout.from(aboutDescription,
    {
        opacity: 0,
        y: 50
    },
    '-=0.2'
)

// PRICING
const pricingHeader = document.getElementById("pricing-header")
const pricingDescription = document.getElementById("pricing-description")
const pricingCards = [...document.querySelectorAll(".card")]

const tlPricing = gsap.timeline()

tlPricing.from(pricingHeader,
    {
        opacity: 0,
        y: 50
    }
)
tlPricing.from(pricingDescription,
    {
        opacity: 0,
        y: 50
    },
    '-=0.2'
)
tlPricing.from(pricingCards, 
    {
        opacity: 0,
        y: 50,
        stagger: 0.2
    },
)

pricingCards.forEach(card => {
    const frontContend = card.querySelector(".front-content")

    card.addEventListener("mouseenter", () => {
        gsap.to(frontContend, 
            {
                y: '-100%',
                ease: "power2.inOut"
            }    
        )
    })

    card.addEventListener("mouseleave", () => {
        gsap.to(frontContend, 
            {
                y: 0,
                ease: "power2.inOut"
            }    
        )
    })
})

// Animate on scroll
const hero = document.getElementById("hero")
const about = document.getElementById("about")
const pricing = document.getElementById("pricing")

ScrollTrigger.create({
    trigger: about,
    start: 'top 80%',
    animation: tlAbout,
    scrub: true,
    end: 'bottom 100%',
})

ScrollTrigger.create({
    trigger: pricing,
    start: 'top 100%',
    animation: tlPricing,
    scrub: true,
    end: 'bottom 100%',
})