// paused: true
const tl = gsap.timeline({repeat: -1})

const texts = [...document.getElementsByClassName("txt")]

console.log(texts)

const duration = 1
const delay = 3
const ease = 'power4.in'

texts.forEach(text => {
    tl  
        .fromTo(text, {y: 100, autoAlpha: 0}, {y:0, autoAlpha:1, duration, ease })
        .fromTo(text, {y:0}, {y: -100, autoAlpha: 0, duration, delay, ease})
})

// setTimeout(() => {
//     tl.play()
// }, 3000)