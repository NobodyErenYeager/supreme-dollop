// const myText = document.getElementById("my-text")

// gsap.to(myText, 
//     {
//        opacity: 1,
//        textContent: "Hello world",
//        duration: 2,
//        delay: 1,
//        skewX: 10,
//        skewY: 10,
//        ease: "power4.out" 
//     }    
// )

const typedText = "Hello, GSAP!"

const animateTextElement = document.getElementById("animate-text")
const cursorElement = document.getElementById("animate-blink")

// console.log(typedText.split(""))
// console.log(typedText.substring(0,3))

const tl = gsap.timeline({onComplete: () => gsap.to(cursorElement,
    {
        opacity: 0,
        textContent: "|",
        repeat: -1,
        yoyo: true,
    }    
)})

typedText.split("").forEach((char, index)=> {
    // console.log(char, index)
    // console.log(typedText.substring(0, index +1))

    tl.to(
        animateTextElement,
        {
           textContent:  typedText.substring(0, index +1),
           duration: 0.2,
        }
    )
})