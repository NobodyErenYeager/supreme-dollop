const triangle = document.getElementById('triangle')
const square = document.getElementById('square')
const circle = document.getElementById('circle')

const rotation = 360
const duration = 1
const scale = 1.2

const tl = gsap.timeline({defaults: {duration:3, ease:'power4.out'}, onComplete: ()=> alert("done")})

tl.to(triangle, {rotation, onComplete: () => alert('hi')}).delay(1).call(()=> alert('hi2'))
tl.to(square, {rotation})
tl.to(circle, {scale})