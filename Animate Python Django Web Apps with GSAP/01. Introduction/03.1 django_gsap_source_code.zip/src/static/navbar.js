const navbar = document.getElementById('navbar')

gsap.from(
    navbar,
    {
        y: -200,
        duration: 1,
        delay: 0.5,
        ease: 'power4.out'
    }
)

// scroll to

// optimzed version
const navLinks = [...document.querySelectorAll(".nav-link")]

navLinks.forEach(link => {
    link.addEventListener("click", ()=> {
        const target = link.id.replace("-link", "")
        gsap.to(window, {scrollTo: `#${target}`})
    })
})

// const heroLink = document.getElementById('hero-link')
// const aboutLink = document.getElementById('about-link')
// const pricingLink = document.getElementById('pricing-link')

// heroLink.addEventListener("click", ()=> {
//     gsap.to(window, {scrollTo: hero })
// })

// aboutLink.addEventListener("click", ()=> {
//     gsap.to(window, {scrollTo: about })
// })

// pricingLink.addEventListener("click", ()=> {
//     gsap.to(window, {scrollTo: pricing })
// })