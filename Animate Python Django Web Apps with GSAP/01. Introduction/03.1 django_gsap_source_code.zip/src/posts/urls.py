from django.urls import path
from .views import PostListFormView

app_name = 'posts'

urlpatterns = [
    path('', PostListFormView.as_view(), name="main"),
]
