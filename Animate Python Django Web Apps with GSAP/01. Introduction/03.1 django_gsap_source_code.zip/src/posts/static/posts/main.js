// ALERT
const alertEl = document.getElementById("alert")

const alertAnimation = gsap.from(alertEl, 
    {
        y: 200,
        duration: 1,
        autoAlpha: 0,
        ease: 'power4.out',
        onComplete: () => {
            setTimeout(()=> {
                alertAnimation.reverse()
            }, 2000)
        }
    }
)

// CARDS
const cards = document.querySelectorAll('.card')

gsap.from(cards,
    {
        scale: 0.1,
        duration: 1,
        opacity: 0,
        ease: 'power4.out',
        stagger: {
            from: "center",
            grid: 'auto',
            // amount: 8,
            each: 0.05,
        }
    },
)