const formModal = document.getElementById("form-modal")
const backdrop = document.getElementById("backdrop")
const openModalBtn = document.getElementById("open-modal-btn")
const cancelBtn = document.getElementById("cancel-btn")

gsap.set(formModal, {autoAlpha: 0, y: 200})
gsap.set(backdrop, {autoAlpha: 0})

const ease = 'power3.out'

const closeModal = () => {
    gsap.to(backdrop, {autoAlpha: 0, duration: 0.1, ease})
    gsap.to(formModal, {y: 200, autoAlpha: 0, duration: 0.3, ease})
}

openModalBtn.addEventListener("click", () => {
    const tl = gsap.timeline()
    tl.to(backdrop, {autoAlpha: 1, duration:0.3, ease})
    tl.to(formModal, {y: 0, autoAlpha: 1, duration: 0.8, ease}, '-=0.15')
    tl.to(formModal, {scale: 1.1, duration: 0.2, ease}, '-=0.15')
    tl.to(formModal, {scale: 1, duration: 0.2, ease})
})

formModal.addEventListener("click", e => {
    if (e.target !== formModal) return
    closeModal()
})

cancelBtn.addEventListener("click", () => {
    closeModal()
})
