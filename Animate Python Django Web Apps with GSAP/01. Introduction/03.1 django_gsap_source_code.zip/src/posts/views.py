from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import ListView, FormView
from .models import Post
from .forms import PostForm
from django.contrib import messages
# Create your views here.

class PostListFormView(FormView, ListView):
    model = Post
    template_name = 'posts/main.html'
    form_class = PostForm
    success_url = reverse_lazy("posts:main")

    def form_valid(self, form):
        form.save()
        messages.add_message(self.request, messages.INFO, "Successfull added a new post")
        return super().form_valid(form)
