from django.views.generic import TemplateView

class HomeView(TemplateView):
    # template_name = 'basics.html'
    # template_name = 'timeline.html'
    # template_name = 'text_1.html'
    # template_name = 'text_2.html'
    template_name = 'main.html'